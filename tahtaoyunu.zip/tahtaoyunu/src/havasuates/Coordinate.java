package havasuates;

public class Coordinate {
	private int coordinatex,coordinatey;

	public Coordinate(int coordinatex, int coordinatey) {
		this.coordinatex = coordinatex;
		this.coordinatey = coordinatey;
	}

	public int getCoordinatex() {
		return coordinatex;
	}

	public void setCoordinatex(int coordinatex) {
		this.coordinatex = coordinatex;
	}

	public int getCoordinatey() {
		return coordinatey;
	}

	public void setCoordinatey(int coordinatey) {
		this.coordinatey = coordinatey;
	}
	
	

}
