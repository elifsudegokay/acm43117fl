package damalioyun;

public class tas {
	String sembol;//her tasın sembolu vardır
	kare onthetop;
	public tas() {
		sembol="T";//her tasın sembolu belli olarak doğar.
		onthetop=null;
		
	}
	public String getSembol() {
		return sembol;
	}
	public void setSembol(String sembol) {
		this.sembol = sembol;
	}
	public kare getOnthetop() {
		return onthetop;
	}
	public void setOnthetop(kare onthetop) {
		this.onthetop = onthetop;
	}
	public boolean canmove(kare hedef) {
		// Şimdilik tek şartımız diğer karenin boş olması
		if (hedef.getT()==null)
		{
			return true;
		}
		
		
		return false;
	}
	

}
