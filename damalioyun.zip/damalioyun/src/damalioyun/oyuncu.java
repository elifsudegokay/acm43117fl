package damalioyun;

public class oyuncu {
	//String name;
tas [] taslar;
tahta tht;
	public void taslaral(tas[] taslar) {
		// TODO Auto-generated method stub
		this.taslar=taslar;
		
		
	}

	public void tahtal(tahta tht) {
		// TODO Auto-generated method stub
		this.tht=tht;
		
		
	}

	public void oyunukur() {
		// burada niye bilinmez tasları ilk satıra koyalım
		for (int i=0;i<taslar.length;i++)
		{
			tasıkoy(1,i,taslar[i]);
		}
		
		
		
	}

	private void tasıkoy(int i, int i2, tas taslar2) {
		// TODO Auto-generated method stub
	//tahtanın yüzeyinde  ilgili kareyi bul	
	kare ilgilikare=tht.getkare(i,i2);	
	//ilgili karenin üzerine tası koy
	//yani hayali referansı tasa cevir
	//ama taşın karesini de taşa bildirmek lazım. Bunu halletmenin bir yolu 
	//sorumluluğu kareye yıkmak ki öyle . Aslında tersi, sorumluluğu tasa yıkmak daha
	// gerçekçi olurdu çünkü taş ağırlık uyguluyor kareye.
	ilgilikare.setT(taslar2);
		
		
	}

	public void tahtayabak() {
		tht.print();
		
	}

	public void oynat(int i, int j, int k, int l) {
		// TODO Auto-generated method stub
		kare yer=tht.getkare(i,j);	
		kare hedef=tht.getkare(k, l);
		//tasıda almak lazım
		tas t=yer.getT();
		//tasa sor gidebilirmi
		if (t.canmove(hedef))
		{
			//yerden kaldır
			yer.kaldır();
			hedef.setT(t);
			
		}
		
		
		
	}

	

}
