package damalioyun;

import javax.swing.JOptionPane;

public class oyun {
	//her damalıtahtalı oyun üç şey gerektirir, oyuncu,
//damalardan oluşmuş tahta, ve taşlar.
	/*
	 * yalnız bizim oyuncumuz biraz gerizekalı, taşlarımız biraz akıllı
	 * olacak şöyle ki taşlar bize bir kareye gidip gidemeyeceklerini söyleyecekler
	 * oyuncu sadece bir tası üstünde olduğu kareden kaldırıp bir sonraki kareye 
	 * konuşlandıracaktır.
	 */
	oyuncu o;
	tahta tht;
	tas taslar []=new tas [2];//şimdilik 8 tane diyelim
	public oyun() {
	//önce oyuncu yaratılmalı , sonra tahta ve taslar
    //sonra tahta ve taşlar oyuncuya verilmeli
	o=new oyuncu();
	//oyuncuya tahta ve tasları verince oyuncu tahta ve taşları biliyor olacak
	//ama tahta ve taşlar birbilerini bilecek mi? Yada söyle diyelim: Biz gerçek hayatta
	//tahta ve tasları bizim yerimize yer bilgisi tutsun diye kullanıyoruz aslında.Aklımıza
	//bir pointer, referans değişkeni. Burada bilmeyi verisini görme olarak
	//düşünün.
	//bu baglamda tahta taşları görür.daha doğrusu tahtanın her bir karesi üstündeki tasın ağırlığını
	//bilir (hisseder, tas basınç uygular,karabasan olur...)
	/*bunca lafın sebebi , tahta ve tası nasıl yaratacağımızın bu nesnelerin bir biri 
	 * ile olan ilişkileri ile ilgili olması. tas butun tahtayı değil sadece bir kareyi
	 * bilir. oyundak bütün amacıda budur. Yani bir kare ile anlamlıdır.Ama kare 
	 * tahtanın üsünde. Tahta yoksa kare yok, kare yoksa oyunda tasın anlamı yok.
	 * Aynı şeyler tahta ve taşlar içinde geçerli. Bu anda bu nesnelerin birbirine
	 * nasıl etki edeceklerine karar vermeye çalışıyoruz.
	 * o zaman şöyle yapalım. tahtayı üstlerinde hayali taşlar olan
	 * karelerden yapalım (yani null bir referans, bir işaretçi ile yaratılım)
	 * 
	 * 
	 * 
	 */
	 tht =new tahta();
	 
	  tas t=new tas();
	  taslar[0]=t;
	  taslar[1]=new tas();
	  o.taslaral(taslar);
	  o.tahtal(tht);
	  o.oyunukur();
	  o.tahtayabak();
		
	}//constructor
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		oyun oy=new oyun();
		oy.o.oynat(1,1,1,2);
		oy.o.tahtayabak();
		oy.o.oynat(1,2,4,2);
		oy.o.tahtayabak();
		while (true)
		{
		String in1=JOptionPane.showInputDialog("enter first coordinate or q to quit");
		if (in1.contains("q"))
		{
			break;
		}
		String in2=JOptionPane.showInputDialog("enter second coordinate or q to quit");
		if (in2.contains("q"))
		{
			break;
		}
		String in3=JOptionPane.showInputDialog("enter first coordinate or q to quit");
		if (in1.contains("q"))
		{
			break;
		}
		String in4=JOptionPane.showInputDialog("enter second coordinate or q to quit");
		if (in2.contains("q"))
		{
			break;
		}
		int i1=Integer.parseInt(in1);
	    int i2=Integer.parseInt(in2);
	    int i3=Integer.parseInt(in3);
	    int i4=Integer.parseInt(in4);
	    oy.o.oynat(i1,i2,i3,i4);
	    oy.o.tahtayabak();
	    		
		}
	}

}
