package damalioyun;

public class tahtatest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
tahta t=new tahta();
t.print();
	}

}
