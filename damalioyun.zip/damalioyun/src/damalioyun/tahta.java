package damalioyun;

public class tahta {
	// her tahtanın yüzeyi 8x8 kareden olusur
kare [][] yuzey=new kare [8][8];

	public tahta() {
		// o zaman her tahtanın var olurken yüzeyi kareler ile kaplanmalıdır.
		for (int i=0;i<8;i++)
		{for (int j=0;j<8;j++)
		{ /* 
		
		*Şimdi her kareyi nasıl yaratacağımıza karar vermemiz
		*gerekiyor.Çünkü kaplamak için kareyi yaratmalısınız.
		*Karenin kordinatları ile anlamlı ve bunlarda yüzeydeki sayılar ile
		*aynı olmalı. Aynı zamanda üzerinde hayali bir taş olmalı.
		*sayıları tahtanın yüzeyi belirliyor.
		*
		*
		*/
		yuzey[i][j]=new kare(i,j);	
		}
		}//fori
	}//cons

	public void print()
	{
		System.out.println("**************");
		
		for (int i=0;i<8;i++)
		{
			System.out.print("|");
			for (int j=0;j<8;j++)
			{
				System.out.print(yuzey[i][j].getDurum()+"|");
			}
			System.out.println();
		}
	}

	public kare[][] getYuzey() {
		return yuzey;
	}

	public void setYuzey(kare[][] yuzey) {
		this.yuzey = yuzey;
	}

	public kare getkare(int i, int i2) {
		// TODO Auto-generated method stub
		return yuzey[i][i2];
	}
}
