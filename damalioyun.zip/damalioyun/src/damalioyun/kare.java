package damalioyun;

public class kare {
	String durum;//boş ise " " değilse tasın simgesi ne ise o
    int satir,sutun;
    tas t;
	public kare(int i, int j) {
		/* her karenin satır ve sütünü tahta tarafından
		 * belirlenir, burada dışarıdan parametre olarak verilir
		 * anlamına geliyor.
		 * 
		 *      */
	satir=i;
	sutun=j;
	//üstünde taşın ağırlığını hissetmez.
	t=null;
	durum=" ";	
	}
	public String getDurum() {
		return durum;
	}
	public void setDurum(String durum) {
		this.durum = durum;
	}
	public int getSatir() {
		return satir;
	}
	public void setSatir(int satir) {
		this.satir = satir;
	}
	public int getSutun() {
		return sutun;
	}
	public void setSutun(int sutun) {
		this.sutun = sutun;
	}
	public tas getT() {
		return t;
	}
	public void setT(tas ts) {
		t=ts;
		
		
		t.onthetop=this;
		durum=t.getSembol();
		 
	}
	public void kaldır() {
		// TODO Auto-generated method stub
		t=null;
		durum=" ";
		
		
	}
	


}
